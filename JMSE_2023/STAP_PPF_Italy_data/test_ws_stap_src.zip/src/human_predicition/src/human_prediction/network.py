#!/usr/bin/env python

import torch.nn as nn
import torch

class CNN(nn.Module):
    def __init__(self,seq_len=10,trend_len=3,num_features=34):
        super().__init__()
        #input is number of steps, features per step, 
        self.fc1 = nn.Linear(in_features=num_features,out_features=20000)
        self.fc2 = nn.Linear(in_features=20000,out_features=10000)
        self.fc3 = nn.Linear(in_features=10000,out_features=5000)
        self.fc4 = nn.Linear(in_features=5000,out_features=5000)
        self.fc5 = nn.Linear(in_features=5000,out_features=seq_len*31)
        self.fc1_dp = nn.Dropout(p=0.1)
        self.fc2_dp = nn.Dropout(p=0.1)
        self.fc3_dp = nn.Dropout(p=0.1)
        self.fc4_dp = nn.Dropout(p=0.1)
        self.relu = nn.ReLU()

    def forward(self, features):
        features = features.unsqueeze(1)
        features = features.unsqueeze(2)
        print(features.type())
        out = self.fc1(features)
#         out = self.fc1_dp(out)
        out = self.relu(out)
        out = self.fc2(out)
#         out = self.fc2_dp(out)
        out = self.relu(out)
        out = self.fc3(out)
#         out = self.fc3_dp(out)
        out = self.relu(out)
        out = self.fc4(out)
#         out = self.fc4_dp(out)
        out = self.relu(out)
#         out = self.fc2(out)
        out = self.fc5(out)

        return out

class CNN_half(nn.Module):
    def __init__(self,seq_len=10,trend_len=3,num_features=26):
        super().__init__()
        #input is number of steps, features per step, 
        self.fc1 = nn.Linear(in_features=num_features,out_features=20000)
        self.fc2 = nn.Linear(in_features=20000,out_features=10000)
        self.fc3 = nn.Linear(in_features=10000,out_features=5000)
        self.fc4 = nn.Linear(in_features=5000,out_features=5000)
        self.fc5 = nn.Linear(in_features=5000,out_features=seq_len*23)
        self.fc1_dp = nn.Dropout(p=0.1)
        self.fc2_dp = nn.Dropout(p=0.1)
        self.fc3_dp = nn.Dropout(p=0.1)
        self.fc4_dp = nn.Dropout(p=0.1)
        self.relu = nn.ReLU()

    def forward(self, features):
        features = features.unsqueeze(1)
        features = features.unsqueeze(2)
        print(features.type())
        out = self.fc1(features)
#         out = self.fc1_dp(out)
        out = self.relu(out)
        out = self.fc2(out)
#         out = self.fc2_dp(out)
        out = self.relu(out)
        out = self.fc3(out)
#         out = self.fc3_dp(out)
        out = self.relu(out)
        out = self.fc4(out)
#         out = self.fc4_dp(out)
        out = self.relu(out)
#         out = self.fc2(out)
        out = self.fc5(out)

        return out

class CNN5(nn.Module):
    def __init__(self,seq_len=10,trend_len=3,num_features=26):#34
        super().__init__()
        self.fc1 = nn.Linear(in_features=num_features,out_features=1000)
        self.fc2 = nn.Linear(in_features=1000,out_features=1000)
        self.fc3 = nn.Linear(in_features=1000,out_features=1000)
        self.fc4 = nn.Linear(in_features=1000,out_features=1000)
        self.fc5 = nn.Linear(in_features=1000,out_features=seq_len*23)
        self.relu1 = nn.SELU()
        self.relu2 = nn.SELU()
        self.relu3 = nn.SELU()
        self.relu4 = nn.SELU()
        
        self.norm1 = nn.LayerNorm(20000)
        self.norm2 = nn.LayerNorm(10000)
        self.norm3 = nn.LayerNorm(5000)
        self.norm4 = nn.LayerNorm(5000)
        
#         self.relu = nn.ReLU()

    def forward(self, features):
        features = features.unsqueeze(1)
        features = features.unsqueeze(2)
        out = self.fc1(features)
        out = self.relu1(out)
        out = self.fc2(out)
        out = self.relu2(out)
        out = self.fc3(out)
        out = self.relu3(out)
        out = self.fc4(out)
        out = self.relu4(out)
        out = self.fc5(out)
        return out

class deCNN(nn.Module):
    def __init__(self):
        super(deCNN, self).__init__()
        self.ngpu = 1
        nz = 26
        ngf = 256
#         self.main = nn.Sequential(
        #ConvTranspose2d(in_channels, out_channels, kernel_size, stride=1, padding=0, output_padding=0, groups=1, bias=True, dilation=1, padding_mode='zeros', device=None, dtype=None)
        # input is Z, going into a convolution
        self.l1=nn.ConvTranspose2d( nz, ngf * 8, (3,6), stride=1, padding=0, bias=False)
        self.l2=nn.BatchNorm2d(ngf * 8)
        self.l3=nn.ReLU(True)
        # state size. (ngf*8) x 4 x 4
        self.l4=nn.ConvTranspose2d(ngf * 8, ngf * 4, 3, stride=1, padding=1, bias=False)
        self.l5=nn.BatchNorm2d(ngf * 4)
        self.l6=nn.ReLU(True)
        # state size. (ngf*4) x 8 x 8
        self.l7=nn.ConvTranspose2d( ngf * 4, ngf * 2, 3, stride=2, padding=1, bias=False)
        self.l8=nn.BatchNorm2d(ngf * 2)
        self.l9=nn.ReLU(True)
        # state size. (ngf*2) x 16 x 16
        self.l10=nn.ConvTranspose2d( ngf * 2, ngf, (2,3), stride=2, padding=(0,0), bias=False)
        self.l11=nn.BatchNorm2d(ngf)
        self.l12=nn.ReLU(True)
        # state size. (ngf) x 32 x 32, 1 output layer (a matrix with seq_len cols and 26 rows)
        self.l13=nn.ConvTranspose2d( ngf, 1, 3, 1, 1, bias=False)
        self.l14=nn.Tanh()
        # state size. (nc) x 64 x 64, nc=1
#         )

    def forward(self, input):
#         print('in:{}'.format(input.shape))
        out = self.l1(input)
#         print('l1 out:{}'.format(out.shape))
        out = self.l2(out)
#         print('l2 out:{}'.format(out.shape))
        out = self.l3(out)
#         print('l3 out:{}'.format(out.shape))
        out = self.l4(out)
#         print('l4 out:{}'.format(out.shape))
        out = self.l5(out)
#         print('l5 out:{}'.format(out.shape))
        out = self.l6(out)
#         print('l6 out:{}'.format(out.shape))
        out = self.l7(out)
#         print('l7 out:{}'.format(out.shape))
        out = self.l8(out)
#         print('l8 out:{}'.format(out.shape))
        out = self.l9(out)
#         print('l9 out:{}'.format(out.shape))
        out = self.l10(out)
#         print('l10 out:{}'.format(out.shape))
        out = self.l11(out)
#         print('l11 out:{}'.format(out.shape))
        out = self.l12(out)
#         print('l12 out:{}'.format(out.shape))
        out = self.l13(out)
#         print('l13 out:{}'.format(out.shape))
        out = self.l14(out)
#         print('l14 out:{}'.format(out.shape))
        return out

class deCNN2(nn.Module):
    def __init__(self):
        super(deCNN2, self).__init__()
        nz = 26 #number of latent vars
        ngf = 32 #factor for length of convolved features
        self.ngpu = 1
#         self.main = nn.Sequential(
        self.l1=nn.ConvTranspose2d( nz, ngf * 8, (3,6), stride=1, padding=0, bias=False)
        self.l2=nn.BatchNorm2d(ngf * 8)
        self.l3=nn.SELU(True)
        # state size. (ngf*8) x 4 x 4
        self.l4=nn.ConvTranspose2d(ngf * 8, ngf * 4, 3, stride=1, padding=1, bias=False)
        self.l5=nn.BatchNorm2d(ngf * 4)
        self.l6=nn.SELU(True)
        # state size. (ngf*4) x 8 x 8
        self.l7=nn.ConvTranspose2d( ngf * 4, ngf * 2, 3, stride=2, padding=1, bias=False)
        self.l8=nn.BatchNorm2d(ngf * 2)
        self.l9=nn.SELU(True)
        # state size. (ngf*2) x 16 x 16
        self.l10=nn.ConvTranspose2d( ngf * 2, ngf, (2,3), stride=2, padding=(0,0), bias=False)
        self.l11=nn.BatchNorm2d(ngf)
        self.l12=nn.SELU(True)
        # state size. (ngf) x 32 x 32, 1 output layer (a matrix with seq_len cols and 26 rows)
        self.l13=nn.ConvTranspose2d( ngf, 1, 3, 1, 1, bias=False)
        self.l14=nn.Tanh()
#         )

    def forward(self, input):
        out = self.l1(input)
        out = self.l2(out)
        out = self.l3(out)
        out = self.l4(out)
        out = self.l5(out)
        out = self.l6(out)
        out = self.l7(out)
        out = self.l8(out)
        out = self.l9(out)
        out = self.l10(out)
        out = self.l11(out)
        out = self.l12(out)
        out = self.l13(out)
        out = self.l14(out)
    
        out1 = nn.functional.normalize(out[:,3:7],dim=1)
        out2 = nn.functional.normalize(out[:,7:11],dim=1)
        out3 = nn.functional.normalize(out[:,11:15],dim=1)
        out4 = nn.functional.normalize(out[:,15:19],dim=1)
        out5 = nn.functional.normalize(out[:,19:23],dim=1)
        out = torch.cat((out[:,:3],out1,out2,out3,out4,out5),1)
        return out