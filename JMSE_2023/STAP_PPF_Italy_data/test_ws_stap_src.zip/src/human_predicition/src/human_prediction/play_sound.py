import os
import time 

def beeper(duration_on, duration_off, freq, cycles):
    for i in range(cycles):
        os.system('play -nq -t alsa synth {} sine {}'.format(duration_on, freq))
        time.sleep(duration_off)
        
def speak_timer(duration,interval,play_zero):
    start_t = time.time()
    notified = False
    decimals = 0
    if interval % 1.0 < 1E-6:
        decimals = 0
    elif interval % 0.1 < 1E-6:
        decimals = 1
    remaining_duration = time.time()-start_t
    while remaining_duration<duration:
        remaining_duration = time.time()-start_t
        if (remaining_duration % interval < 0.1) and (play_zero or (remaining_duration - duration < 0.0)):
            if not notified:
                speak_str = ''
                if decimals>0:
                    speak_str = 'spd-say "{}"'.format(round(duration-remaining_duration,decimals))
                else:                    
                    speak_str = 'spd-say "{}"'.format(round(duration-remaining_duration))
                os.system(speak_str)
                notified = True
        else:
            notified = False