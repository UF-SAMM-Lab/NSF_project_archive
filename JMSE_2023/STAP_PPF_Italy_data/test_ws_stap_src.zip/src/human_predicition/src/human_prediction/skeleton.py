#!/usr/bin/env python
# import rospy
import numpy as np
from human_prediction.quat_functions import *

#function to compute the spine, shoulder, elbow, wrist, and head top locations
#given the rpy at each joint.  The coordinates of the pelvis must be given since
#other transformations start from that location.  
#dimension[0] = spine length, [1]=neck/head length, [2] = shoulder to shoulder length
#[3] = L upper arm length, [4] = L forearm length, [5]/[6] = R upper arm/forearm length
def forwardKinematics_fixed(data,dimension):
    z_axis_quat = np.array([0,0,0,1])
    points = np.zeros((3,15))
    points[:,0] = data[:3]
    q1 = data[3:7]
    z_spine = quaternion_multiply(quaternion_multiply(q1,np.array([0,0,0,1])),quat_inv(q1))
    points[:,1] = points[:,0]+dimension[0]*np.array(z_spine[1:]).reshape((3))
    q2 = data[7:11]
    z_neck = quaternion_multiply(quaternion_multiply(q2,z_axis_quat),quat_inv(q2))
    points[:,2] = points[:,1]+dimension[1]*np.array(z_neck[1:]).reshape((3))
    q3 = data[11:15]
    z_shoulders = quaternion_multiply(quaternion_multiply(q3,z_axis_quat),quat_inv(q3))
    points[:,3] = points[:,1]-0.5*dimension[2]*np.array(z_shoulders[1:]).reshape((3))
    q4 = data[15:19]
    z_e1 = quaternion_multiply(quaternion_multiply(q4,z_axis_quat),quat_inv(q4))
    points[:,4] = points[:,3]+dimension[3]*np.array(z_e1[1:]).reshape((3))
    q5 = data[19:23]
    z_w1 = quaternion_multiply(quaternion_multiply(q5,z_axis_quat),quat_inv(q5))
    points[:,5] = points[:,4]+(dimension[4]+0.15)*np.array(z_w1[1:]).reshape((3))
    points[:,6] = points[:,1]+0.5*dimension[2]*np.array(z_shoulders[1:]).reshape((3))
    q6 = data[23:27]
    z_e2 = quaternion_multiply(quaternion_multiply(q6,z_axis_quat),quat_inv(q6))
    points[:,7] = points[:,6]+dimension[5]*np.array(z_e2[1:]).reshape((3))
    q7 = data[27:]
    z_w2 = quaternion_multiply(quaternion_multiply(q7,z_axis_quat),quat_inv(q7))
    points[:,8] = points[:,7]+(dimension[6]+0.15)*np.array(z_w2[1:]).reshape((3))
    return points