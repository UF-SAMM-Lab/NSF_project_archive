#!/usr/bin/env python

from nbformat import write
import rospy
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d,Axes3D
from human_prediction.quat_functions import *
import os
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean, minkowski
from human_prediction.network import *
from std_msgs.msg import Float32MultiArray, Float32, Bool
import rospkg
from human_prediction.skeleton import *
from scipy import interpolate as interp
import time
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from scipy.signal import butter, lfilter
import time
from human_prediction.play_sound import beeper, speak_timer
import threading

reaching_target = np.array([-0.4,0,0.3])
current_pose = np.zeros((31))
new_pose_available = False
new_tgt_available = False
dimensions = [0.569,0.25,0.328,0.285,0.4,0.285,0.4]
start = False
active_hand = 0
force_hand = ''

def current_pose_callback(data):
    global new_pose_available, current_pose
    current_pose = np.asarray(data.data,dtype=float)
    new_pose_available = True

def reaching_callback(data):
    global new_tgt_available,reaching_target, active_hand
    reaching_target = np.array(data.data)
    if len(force_hand)==0:
        if (abs(reaching_target[0])>0.05):
            if (reaching_target[0]<0):
                active_hand = 0
            else:
                active_hand = 1
    print('new reaching target:{}, act hand:{}'.format(reaching_target, 'left' if active_hand else 'right'))
    os.system('spd-say "new reach target, x={}, y={}, z={}"'.format(round(reaching_target[0],2),round(reaching_target[1],2),round(reaching_target[2],2)))
    new_tgt_available = True

def dims_callback(data):
    global dimensions
    dimensions = np.asarray(data.data,dtype=float)

def start_cb(data):
    global start
    start= data.data

if __name__ == '__main__':

    rospy.init_node('skeleton_predictor', anonymous=True)
    rospy.Subscriber('/skeleton_quats', Float32MultiArray, current_pose_callback)
    rospy.Subscriber('/human_0/reaching_target', Float32MultiArray, reaching_callback)
    rospy.Subscriber('/human_0/dimensions', Float32MultiArray, dims_callback)
    rospy.Subscriber('/start_prediction', Bool, start_cb)

    pred_human_pub = rospy.Publisher('predicted_human',MarkerArray,queue_size=1)
    pub_wrist_sped = rospy.Publisher('wrist_spd',Float32,queue_size=1)
    pub_tgt = rospy.Publisher('reaching_tgt_marker',Marker,queue_size=1)

    rospack = rospkg.RosPack()
    this_pack = rospack.get_path('human_prediction')

    reaching_target = np.asarray(rospy.get_param("/predict/reaching_target").split(','),dtype=float)
    print(reaching_target)
    sequence_length = 10
    average_wrist_velocity = 0.3 #m/s
    if os.path.exists(os.path.join(this_pack,'data','avg_wrist_speed.csv')):
        try:
            average_wrist_velocity = np.genfromtxt(os.path.join(this_pack,'data','avg_wrist_speed.csv'),dtype=float,delimiter=',')[0]
            print(average_wrist_velocity)
        except:
            pass
    dt = 0.1
    net_type = rospy.get_param("/predict/net_type")
    radii = rospy.get_param('/human_link_radii')
    print(radii)
    num_features = 31

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if net_type<2:
        num_features = 31
        left_model = CNN().to(device)
        right_model = CNN().to(device)
    elif (net_type==2):
        num_features = 23
        left_model = CNN_half().to(device)
        right_model = CNN_half().to(device)
    elif (net_type==3):
        num_features = 23
        left_model = CNN5().to(device)
        right_model = CNN5().to(device)
    elif (net_type==4):
        num_features = 23
        left_model = deCNN2().to(device)
        right_model = deCNN2().to(device)

    # left_model_name = os.path.join(this_pack,'src','reaching_left_NN_state_dict.pt')
    right_model_name = os.path.join(this_pack,'src','nets','net{}'.format(net_type),'reaching_right_NN_state_dict.pt')
    # right_model_name = os.path.join(this_pack,'src','reaching_right_NN_state_dict.pt')
    left_model_name = os.path.join(this_pack,'src','nets','net{}'.format(net_type),'reaching_left_NN_state_dict.pt')
    if torch.cuda.is_available():
        print('using gpu')
    else:
        print('using cpu')
    left_model.load_state_dict(torch.load(left_model_name,map_location=device))
    right_model.load_state_dict(torch.load(right_model_name,map_location=device))

    left_model.eval()
    right_model.eval()

    active_hand = 0 #1 = left, 0 = right
    force_hand = rospy.get_param("/predict/force_hand")
    if force_hand=='left':
        print('forced left hand')
        active_hand = 1
    elif force_hand=='right':
        print('forced right hand')
        active_hand = 0
    rec_nums = np.array([0])
    
    for filename in os.listdir(os.path.join(this_pack,'data')):
        # print(filename)
        if filename.startswith('recording_'):
            if filename.endswith('.csv'):
                file_parts = filename.split('_')
                rec_nums = np.append(rec_nums,file_parts[1].split('.')[0])
    rec_num = np.max(rec_nums.astype(int))+1
    print(rec_num)

    record_cols = np.concatenate((np.arange(1,4),np.arange(5,35)))
    print(record_cols)

    while (not rospy.is_shutdown()) and (not new_pose_available):
        print('waiting for skeleton',end='\r')
        rospy.sleep(1.0)

    workcell_range = np.array([[-1,-1,-0.5],[1,1,1.5]])
    rng = workcell_range[1,:]-workcell_range[0,:]

    mkr_idxs = np.array([[0,1,3,4,6,7],[1,2,4,5,7,8],[0,1,3,4,5,6],[0,1,3,4,5,6]])
    start_color = np.array([0,1,0])
    color_diff = np.array([1,0,0])-start_color

    filt = butter(1, 0.02, btype='lowpass', analog=False)
    start_pelvis = np.zeros((3))
    min_seq=0
    seq_start = time.time()
    #beeper parameters
    duration_on = 0.2  # seconds
    duration_off = 0.2
    freq = 880  # Hz
    cycles = 1
    th = None

    while not rospy.is_shutdown():
        if th is not None:
            th.join()
        print('reaching target:{}'.format(reaching_target))
        while (not rospy.is_shutdown()) and (not start):
            print('waiting for start',end='\r')
            rospy.sleep(1.0)
        # print('starting in 3',end='\r')
        # rospy.sleep(1.0)
        # print('starting in 2',end='\r')
        # rospy.sleep(1.0)
        # print('starting in 1',end='\r')
        # rospy.sleep(1.0)
        os.system('spd-say "starting in"')
        time.sleep(1.0)
        speak_timer(3.0,1.0,False)
        th = threading.Thread(target=beeper, args=(duration_on,duration_off,freq,cycles))
        th.start()
        seq_start = time.time()
        prev_time = time.time_ns()
        rec_start = False
        data = np.empty((0,81))
        data_buffer = np.empty((0,81))
        prediction = np.empty((0,77))
        start_time = time.time_ns()
        prev_joints = None
        rec_started = False
        joint_vels = np.zeros((100))
        j_v_idx = 0
        wrist_spds = np.empty((0))
        seq_joints = []
        prediction_made = False
        done_steps = 0
        start_steps = 0
        stop_record_steps = 0
        stop_record = False
        while not rospy.is_shutdown():
            current_joints = forwardKinematics_fixed(current_pose[1:], dimensions)

            # print(current_pose[1:])
            if prev_joints is None:
                prev_joints=current_joints
            if new_pose_available:
                if not prediction_made:
                    seq_start = time.time()
                    mkr = Marker()
                    mkr.id=0
                    mkr.type=mkr.SPHERE
                    mkr.color.g=1.0
                    mkr.color.a=1.0
                    mkr.pose.position.x = reaching_target[0]
                    mkr.pose.position.y = reaching_target[1]
                    mkr.pose.position.z = reaching_target[2]
                    mkr.pose.orientation.x = 0
                    mkr.pose.orientation.y = 0
                    mkr.pose.orientation.z = 0
                    mkr.pose.orientation.w = 1
                    mkr.scale.x = 0.05
                    mkr.scale.y = 0.05
                    mkr.scale.z = 0.05
                    mkr.header.frame_id = 'world'
                    pub_tgt.publish(mkr)
                    new_pose_available = False
                    prediction_made = True
                    # print(np.concatenate((reaching_target-current_pose[1:4],current_pose[1:])))
                    inputs = np.concatenate((reaching_target-current_pose[1:4],current_pose[1:]))
                    start_pelvis = np.copy(current_pose[1:4])
                    if net_type==0: #percent pelvis motion
                        # inputs = np.concatenate((reaching_target-current_pose[1:4],current_pose[1:]))
                        inputs[3:6] = (inputs[3:6]-workcell_range[0,:])/rng
                    elif net_type==1: #relative pelvis motion
                        # inputs = np.concatenate((reaching_target-current_pose[1:4],current_pose[1:]))
                        inputs[3:6] = inputs[3:6]-current_pose[1:4]
                    elif ((net_type==2) or (net_type==3) or (net_type==4)): 
                        # inputs = np.concatenate((reaching_target-current_pose[1:4],current_pose[1:]))
                        inputs[3:6] = inputs[3:6]-current_pose[1:4]
                        cols = np.arange(0,18)
                        if active_hand==0: #right arm
                            cols = np.append(cols,np.arange(18,26))
                            other_arm_prediction = np.tile(np.expand_dims(current_pose[np.arange(24,32)],axis=0),(sequence_length,1))
                        else: #left arm
                            cols = np.append(cols,np.arange(26,34))
                            other_arm_prediction = np.tile(np.expand_dims(current_pose[np.arange(16,24)],axis=0),(sequence_length,1))
                        inputs = inputs[cols]
                    x = torch.from_numpy(inputs).float().to(device)
                    if net_type==4:
                        x = torch.reshape(x,(1,26,1,1))
                    else:
                        x = x.unsqueeze(0)
                    # print(x.shape)
                    if active_hand==0:#right arm
                        yhat = right_model(x)
                        path_time = np.linalg.norm(current_joints[:,5]-reaching_target)/average_wrist_velocity
                    else:
                        yhat = left_model(x)
                        path_time = np.linalg.norm(current_joints[:,8]-reaching_target)/average_wrist_velocity
                    print('path time:{}'.format(path_time))
                    y_out = yhat[0].cpu().detach().numpy().reshape((sequence_length,num_features))
                    print(y_out.shape)
                    if ((net_type==2) or (net_type==3) or (net_type==4)):
                        if active_hand==0:#right arm
                            y_out = np.append(y_out,other_arm_prediction,axis=1)
                        else:
                            y_out = np.insert(y_out,[15],other_arm_prediction,axis=1)
                    for i in range(y_out.shape[0]):
                        if net_type==0:
                            y_out[i,:3] = np.multiply(y_out[i,:3],rng)+workcell_range[0,:]
                        else:
                            y_out[i,:3] = y_out[i,:3]+current_pose[1:4]

                    for i in range(7):
                        n = np.linalg.norm(y_out[:,i*4+3:i*4+7],axis=1)
                        y_out[:,i*4+3:(i+1)*4+3] = y_out[:,i*4+3:(i+1)*4+3]/n[:,None]
                    
                    # print(y_out)
                    
                    f = interp.interp1d(np.arange(sequence_length),y_out,kind='linear',axis=0) 
                    seq = f(np.linspace(0,sequence_length-1,num=math.ceil(path_time/dt)))
                    mkr_arr = MarkerArray()
                    for i in range(seq.shape[0]):
                        seq_joints.append(forwardKinematics_fixed(seq[i], dimensions))
                        tmp_row = np.concatenate(([i*dt],seq[i],(seq_joints[-1].T).flatten()))
                        prediction = np.append(prediction,np.expand_dims(tmp_row,axis=0),axis=0)
                        for a in range(6):
                            mkr = Marker()
                            mkr.id=len(mkr_arr.markers)+1
                            mkr.lifetime = rospy.Duration(30)
                            mkr.type=mkr.CYLINDER
                            c = color_diff*(i/seq.shape[0])+start_color
                            mkr.color.r=c[0]
                            mkr.color.b=c[1]
                            mkr.color.g=c[2]
                            mkr.color.a=0.2
                            tmp_pt = 0.5*(seq_joints[-1][:,mkr_idxs[0,a]]+seq_joints[-1][:,mkr_idxs[1,a]])
                            mkr.pose.position.x = tmp_pt[0]
                            mkr.pose.position.y = tmp_pt[1]
                            mkr.pose.position.z = tmp_pt[2]
                            mkr.pose.orientation.x = seq[i,4+mkr_idxs[2,a]*4]
                            mkr.pose.orientation.y = seq[i,5+mkr_idxs[2,a]*4]
                            mkr.pose.orientation.z = seq[i,6+mkr_idxs[2,a]*4]
                            mkr.pose.orientation.w = seq[i,3+mkr_idxs[2,a]*4]
                            mkr.scale.x = 2*radii[mkr_idxs[3,a]]
                            mkr.scale.y = 2*radii[mkr_idxs[3,a]]
                            mkr.scale.z = dimensions[mkr_idxs[3,a]]
                            mkr.header.frame_id = 'world'
                            mkr_arr.markers.append(mkr)
                    pred_human_pub.publish(mkr_arr)

                    seq_start = time.time()

                # else:
                error = 0
                wrist_spd=0
                if active_hand==0:
                    error = np.linalg.norm(current_joints[:,5]-reaching_target)
                    wrist_spd = np.linalg.norm(current_joints[:,5]-prev_joints[:,5])/(time.time_ns()-prev_time)*1e9
                    outputs = np.copy(current_pose[1:])
                else:
                    error = np.linalg.norm(current_joints[:,8]-reaching_target)
                    wrist_spd = np.linalg.norm(current_joints[:,8]-prev_joints[:,8])/(time.time_ns()-prev_time)*1e9
                min_err = 1000
                for r in range(len(seq_joints)):
                    joint_errors = np.sum(np.linalg.norm(current_joints-seq_joints[r],axis=0))
                    if joint_errors<min_err:
                        min_err = joint_errors
                        min_seq = r
                
                # print('seq match:{}'.format(min_seq))
                joint_vels = np.roll(joint_vels,-1,axis=0)
                joint_vels[-1] = wrist_spd
                avg_wrist_speed = np.mean(joint_vels)
                pub_wrist_sped.publish(Float32(avg_wrist_speed))

                if (not rec_start):
                    if (avg_wrist_speed>0.2):
                        start_steps+=1
                    else:
                        start_steps = 0
                    if start_steps>10:
                        rec_start = True
                        start_time = time.time_ns()
                else:
                    if (error<0.2) and (avg_wrist_speed<0.2):
                        done_steps+=1
                    else:
                        done_steps = 0
                    if done_steps>50:
                        stop_record = True
                    if stop_record: 
                        stop_record_steps += 1
                        if (stop_record_steps>100):
                            rec_start = False
                print('seq match:{:.5f}, seq time:{:.5f}, e:{: 1.5f}, s:{: 1.3f}'.format(min_seq*dt,time.time()-seq_start,error,avg_wrist_speed))

                prev_joints = current_joints
                prev_time = time.time_ns()
                data_row = np.concatenate(([(time.time_ns()-start_time)*1e-9],reaching_target,current_pose,(current_joints.T).flatten()))
                data_buffer = np.append(data_buffer,np.expand_dims(data_row,axis=0),axis=0)
                if rec_start and (not rec_started):
                    rec_started = True
                    print('rec started at {}'.format((time.time_ns()-start_time)*1e-9))
                    data = data_buffer[-200:,:]
                elif (not rec_start) and rec_started:
                    data = np.append(data,np.expand_dims(data_row,axis=0),axis=0)
                    rec_started = False
                    print('rec stopped at {}'.format((time.time_ns()-start_time)*1e-9))
                    th2 = threading.Thread(target=beeper, args=(duration_on,duration_off,440,2))
                    th2.start()
                    th2.join()
                    break
                    # data = data[:data.shape[0]-10,:]
                elif rec_started:
                    data = np.append(data,np.expand_dims(data_row,axis=0),axis=0)
                    wrist_spds = np.append(wrist_spds,[avg_wrist_speed])

            rospy.sleep(0.01)
        if not rospy.is_shutdown():
            np.savetxt(os.path.join(this_pack,'data','recording_{}.csv'.format(rec_num)),data,delimiter=',')
            np.savetxt(os.path.join(this_pack,'data','recorded_quats_{}_{}.csv'.format(rec_num,'w2' if active_hand else 'w1')),data[:,record_cols],delimiter=',')
            np.savetxt(os.path.join(this_pack,'data','prediction_{}.csv'.format(rec_num)),prediction,delimiter=',')
            np.savetxt(os.path.join(this_pack,'data','avg_wrist_speed.csv'),np.array([np.mean(wrist_spds)]),delimiter=',')
        print('average wrist speed={}',np.mean(wrist_spds))
        rec_num+=1
        start = False
        # rospy.sleep(3)
    

