
from nbformat import write
import rospy
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d,Axes3D
from human_prediction.quat_functions import *
import os
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean, minkowski
from human_prediction.network import *
from std_msgs.msg import Float32MultiArray, Float32, Bool,Float64MultiArray,MultiArrayDimension
import rospkg
from human_prediction.skeleton import *
from scipy import interpolate as interp
import time
from visualization_msgs.msg import MarkerArray
from visualization_msgs.msg import Marker
from scipy.signal import butter, lfilter
import time
from human_prediction.play_sound import beeper, speak_timer
import threading
import json
from jsk_rviz_plugins.msg import OverlayText

from human_prediction.srv import human_prediction,human_predictionResponse,human_motion_done,human_motion_doneResponse, human_motion_reset,human_motion_resetResponse

sequence_length = 10
device = "cpu"#torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
dimensions = [0.569,0.25,0.328,0.285,0.4,0.285,0.4]
num_features = 23
left_model = deCNN2().to(device)
right_model = deCNN2().to(device)
net_type = 4    
rospack = rospkg.RosPack()
this_pack = rospack.get_path('human_prediction')
# left_model_name = os.path.join(this_pack,'src','reaching_left_NN_state_dict.pt')
right_model_name = os.path.join(this_pack,'src','nets','net{}'.format(net_type),'reaching_right_NN_state_dict.pt')
# right_model_name = os.path.join(this_pack,'src','reaching_right_NN_state_dict.pt')
left_model_name = os.path.join(this_pack,'src','nets','net{}'.format(net_type),'reaching_left_NN_state_dict.pt')
if torch.cuda.is_available():
    print('using gpu')
else:
    print('using cpu')
left_model.load_state_dict(torch.load(left_model_name,map_location=device))
right_model.load_state_dict(torch.load(right_model_name,map_location=device))

left_model.eval()
right_model.eval()

cur_pose = np.zeros((31))
prev_pose=cur_pose
prev_pose_time = time.time_ns()
cur_pose_time = time.time_ns()
dimensions = [0.569,0.25,0.328,0.285,0.4,0.285,0.4]

joint_vels = np.zeros((20))
rec_start = False
done_steps = 0
start_steps = 0
stop_record = False
stop_record_steps = 0
avg_wrist_speed_increased = False
avg_speed_steps = 0
dt = 0.1
pub_done_status = None
pub_done_status2 = None


filt = butter(1, 0.02, btype='lowpass', analog=False)

def current_pose_callback(data):
    global cur_pose,prev_pose,prev_pose_time,cur_pose_time
    prev_pose = cur_pose
    prev_pose_time = cur_pose_time
    cur_pose = np.asarray(data.data,dtype=float)
    cur_pose_time = time.time_ns()

def dims_callback(data):
    global dimensions
    dimensions = np.asarray(data.data,dtype=float)

def avg_wrist_vel(dist):
    return -0.214*dist*dist+0.659*dist-0.0176

def predict(req):
    reaching_target = np.asarray(req.reach_target,float)
    # print(reaching_target)
    active_hand = req.active_hand #0==right
    dt = req.dt
    current_pose = np.asarray(req.start_pose,float)
    # print(current_pose.shape)
    current_joints = forwardKinematics_fixed(current_pose, dimensions)
    inputs = np.concatenate((reaching_target-current_pose[:3],current_pose))
    start_pelvis = np.copy(current_pose[:3])
    inputs[3:6] = inputs[3:6]-current_pose[:3]
    cols = np.arange(0,18)
    if active_hand==0: #right arm
        cols = np.append(cols,np.arange(18,26))
        other_arm_prediction = np.tile(np.expand_dims(current_pose[np.arange(23,31)],axis=0),(sequence_length,1))
    else: #left arm
        cols = np.append(cols,np.arange(26,34))
        other_arm_prediction = np.tile(np.expand_dims(current_pose[np.arange(15,23)],axis=0),(sequence_length,1))
    inputs = inputs[cols]
    x = torch.from_numpy(inputs).float().to(device)
    x = torch.reshape(x,(1,26,1,1))
    if active_hand==0:#right arm
        yhat = right_model(x)
        dist = np.linalg.norm(current_joints[:,5]-reaching_target)
        path_time = dist/avg_wrist_vel(dist)
    else:
        yhat = left_model(x)
        dist = np.linalg.norm(current_joints[:,8]-reaching_target)
        path_time = dist/avg_wrist_vel(dist)
    if (path_time<0) or (math.isnan(path_time)):
        print('human path time:{}'.format(path_time))
        print('avg vel:',avg_wrist_vel(dist),' dist:',dist)
        print('reaching_target:',reaching_target)
        print('current_joints',current_joints)
        print('dt',dt)
    y_out = yhat[0].cpu().detach().numpy().reshape((sequence_length,num_features))
    if active_hand==0:#right arm
        y_out = np.append(y_out,other_arm_prediction,axis=1)
    else:
        y_out = np.insert(y_out,[15],other_arm_prediction,axis=1)
    for i in range(y_out.shape[0]):
        y_out[i,:3] = y_out[i,:3]+current_pose[:3]

    for i in range(7):
        n = np.linalg.norm(y_out[:,i*4+3:i*4+7],axis=1)
        y_out[:,i*4+3:(i+1)*4+3] = y_out[:,i*4+3:(i+1)*4+3]/n[:,None]
    f = interp.interp1d(np.arange(sequence_length),y_out,kind='linear',axis=0) 
    num_pts = max(math.ceil(path_time/dt),0)+1
    seq = f(np.linspace(0,sequence_length-1,num=num_pts))
    time_ax = np.arange(0,num_pts)*dt
    seq_w_time = np.concatenate((time_ax.reshape((time_ax.shape[0],1)),seq),axis=1)
    res_msg = Float32MultiArray()
    res_msg.layout.dim.append(MultiArrayDimension())
    res_msg.layout.dim[0].label="cols"
    res_msg.layout.dim[0].size = seq_w_time.shape[1]
    res_msg.data = seq_w_time.flatten().tolist()
    # print(res_msg.data)
    return human_predictionResponse(res_msg)

def is_done(req):
    global cur_pose,prev_pose,prev_pose_time,cur_pose_time, joint_vels
    global start_steps, done_steps, rec_start, stop_record, stop_record_steps
    global avg_wrist_speed_increased,avg_speed_steps
    reaching_target = np.asarray(req.reach_target,float)
    active_hand = req.active_hand
    error = 0
    wrist_spd=0
    if np.all(cur_pose==0.0):
        return human_motion_doneResponse(False)
    current_joints = forwardKinematics_fixed(cur_pose[1:], dimensions)
    prev_joints = forwardKinematics_fixed(prev_pose[1:], dimensions)
    cur_wrist = current_joints[:,5]
    if active_hand==0:
        error = np.linalg.norm(current_joints[:,5]-reaching_target)
        cur_wrist = current_joints[:,5]
        wrist_spd = np.linalg.norm(current_joints[:,5]-prev_joints[:,5])/(cur_pose_time-prev_pose_time)*1e9
    else:
        error = np.linalg.norm(current_joints[:,8]-reaching_target)
        cur_wrist = current_joints[:,8]
        wrist_spd = np.linalg.norm(current_joints[:,8]-prev_joints[:,8])/(cur_pose_time-prev_pose_time)*1e9
    
    # print('seq match:{}'.format(min_seq))
    joint_vels = np.roll(joint_vels,-1,axis=0)
    joint_vels[-1] = wrist_spd
    avg_wrist_speed = lfilter(filt[0],filt[1],joint_vels)[-1]#np.mean(joint_vels)
    if (avg_wrist_speed>0.05):
        avg_speed_steps += 1
    else:
        avg_speed_steps = 0
    avg_wrist_speed_increased = avg_speed_steps>5
    msg = Float32MultiArray()
    msg.data.append(active_hand)
    for t in range(3):
        msg.data.append(reaching_target[t])
    msg.data.append(avg_wrist_speed)
    msg.data.append(avg_wrist_speed_increased)
    msg.data.append(error)
    msg.data.append(done_steps)
    pub_done_status.publish(msg)

    msg2 = OverlayText()    
    msg2.action = msg2.ADD
    msg2.width = 500
    msg2.height = 100
    msg2.left = 500
    msg2.top = 0
    msg2.text_size = 24
    msg2.line_width = 6
    msg2.font = "DejaVu Sans Mono"
    txt = str(round(reaching_target[0],2)) + "," + str(round(reaching_target[1],2)) + "," + str(round(reaching_target[2],2)) + ":" + str(round(cur_wrist[0],2)) + "," + str(round(cur_wrist[1],2)) + "," + str(round(cur_wrist[2],2))
    msg2.text = txt
    msg2.fg_color.r = 25.0/255.0
    msg2.fg_color.g = 1.0
    msg2.fg_color.b = 240.0/255.0
    msg2.fg_color.a = 1.0
    msg2.bg_color.r = 0.0
    msg2.bg_color.g = 0.0
    msg2.bg_color.b = 0.0
    msg2.bg_color.a = 0.2
    pub_done_status2.publish(msg2)
    # print('arm:{}, tgt: {}\n, spd:{:3f}, spd inc:{}, error:{:3f}, done_steps:{}'.format('left' if active_hand else 'right', reaching_target, avg_wrist_speed,avg_wrist_speed_increased,error,done_steps))
    # pub_wrist_sped.publish(Float32(avg_wrist_speed))

    if (error<0.5) and (avg_wrist_speed<0.5) and (avg_wrist_speed_increased):
        done_steps+=1
    else:
        done_steps = 0
    return human_motion_doneResponse(done_steps>5)

def starting_new_motion(req):
    global done_steps, rec_start, stop_record, stop_record_steps,avg_wrist_speed_increased,avg_speed_steps
    done_steps = 0
    avg_wrist_speed_increased = False
    avg_speed_steps=0
    rec_start = True
    stop_record = False
    stop_record_steps = 0
    joint_vels = np.zeros((20))
    return human_motion_resetResponse()

if __name__=="__main__":
    rospy.init_node('predictor_demonstrator', anonymous=True)
    rospy.Subscriber('/skeleton_quats', Float32MultiArray, current_pose_callback)
    rospy.Subscriber('/human_0/dimensions', Float32MultiArray, dims_callback)
    pub_done_status = rospy.Publisher('human_task_status',Float32MultiArray,queue_size=1)
    pub_done_status2 = rospy.Publisher('human_task_status_str',OverlayText,queue_size=1)
    s = rospy.Service('predict_human',human_prediction,predict)
    s2 = rospy.Service('human_motion_done',human_motion_done,is_done)
    s3 = rospy.Service('human_motion_reset',human_motion_reset,starting_new_motion)
    print('ready to predict human motions')
    print('ready to test if human motion done')
    print('ready to reset human motions')
    rospy.spin()