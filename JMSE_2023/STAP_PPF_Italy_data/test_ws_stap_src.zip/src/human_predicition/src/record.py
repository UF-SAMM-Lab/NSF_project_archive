#!/usr/bin/env python

from nbformat import write
import rospy
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d,Axes3D
from human_prediction.quat_functions import *
import os
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean, minkowski
from human_prediction.network import *
from std_msgs.msg import Float32MultiArray
import rospkg
from human_prediction.skeleton import *
from scipy import interpolate as interp
import time

reaching_target = np.array([-0.4,0,0.3])
current_pose = np.zeros((31))
new_pose_available = False
new_tgt_available = False
dimensions = [0.569,0.25,0.328,0.285,0.4,0.285,0.4]

def current_pose_callback(data):
    global new_pose_available, current_pose
    current_pose = np.asarray(data.data,dtype=float)
    new_pose_available = True

def dims_callback(data):
    global dimensions
    dimensions = np.asarray(data.data,dtype=float)

if __name__ == '__main__':

    rospy.init_node('skeleton_recorder', anonymous=True)
    rospy.Subscriber('/skeleton_quats', Float32MultiArray, current_pose_callback)
    rospy.Subscriber('/human_0/dimensions', Float32MultiArray, dims_callback)


    rospack = rospkg.RosPack()
    this_pack = rospack.get_path('human_prediction')


    done_steps = 0
    start_steps = 0

    rec_nums = np.array([0])
    
    for filename in os.listdir(os.path.join(this_pack,'training_data')):
        # print(filename)
        if filename.startswith('trainingRecord_'):
            if filename.endswith('.csv'):
                file_parts = filename.split('_')
                rec_nums = np.append(rec_nums,file_parts[1].split('.')[0])
    rec_num = np.max(rec_nums.astype(int))+1
    print(rec_num)

    while (not rospy.is_shutdown()) and (not new_pose_available):
        print('waiting for skeleton')
        rospy.sleep(1.0)
    
    print('starting in 3')
    rospy.sleep(1.0)
    print('starting in 2')
    rospy.sleep(1.0)
    print('starting in 1')
    rospy.sleep(1.0)

    prev_time = time.time_ns()
    rec_start = False
    data = np.empty((0,32))
    data_buffer = np.empty((0,32))
    start_time = time.time_ns()
    prev_joints = None
    rec_started = False
    wrist_spds = np.empty((0))
    joint_vels = np.zeros((10))
    j_v_idx = 0

    while not rospy.is_shutdown():
        cycle_start = time.time_ns()
        current_joints = forwardKinematics_fixed(current_pose[1:], dimensions)
        if prev_joints is None:
            prev_joints=current_joints
        if new_pose_available:
            error = 0
            wrist_spd_1 = np.linalg.norm(current_joints[:,5]-prev_joints[:,5])/(time.time_ns()-prev_time)*1e9
            wrist_spd_2 = np.linalg.norm(current_joints[:,8]-prev_joints[:,8])/(time.time_ns()-prev_time)*1e9
            
            joint_vels[j_v_idx] = max(wrist_spd_1,wrist_spd_2)
            avg_wrist_speed = np.mean(joint_vels)
            # print(max_avg_vel)
            j_v_idx+=1
            if j_v_idx>joint_vels.shape[0]-1:
                j_v_idx = 0
            
            if (not rec_start):
                if (avg_wrist_speed>0.2):
                    start_steps+=1
                else:
                    start_steps = 0
                if start_steps>10:
                    rec_start = True
                    start_time = time.time_ns()
            elif (current_pose[1]<-1):
                rec_start = False
            print('s:{: 1.3f}'.format(avg_wrist_speed))

            prev_joints = current_joints
            prev_time = time.time_ns()
            data_row = np.concatenate(([(time.time_ns()-start_time)*1e-9],current_pose[1:]))
            data_buffer = np.append(data_buffer,np.expand_dims(data_row,axis=0),axis=0)
            if rec_start and (not rec_started):
                rec_started = True
                for i in range(10):
                    data = data_buffer[-10:,:]
            elif (not rec_start) and rec_started:
                data = np.append(data,np.expand_dims(data_row,axis=0),axis=0)
                rec_started = False
                break
                # data = data[:data.shape[0]-10,:]
            elif rec_started:
                data = np.append(data,np.expand_dims(data_row,axis=0),axis=0)
                wrist_spds = np.append(wrist_spds,[avg_wrist_speed])
        sleep_time = 1/30-(time.time_ns()-cycle_start)*1e-9
        rospy.sleep(sleep_time)

    np.savetxt(os.path.join(this_pack,'training_data','trainingRecord_{}.csv'.format(rec_num)),data,delimiter=',')
    print('average wrist speed={}',np.mean(wrist_spds))

