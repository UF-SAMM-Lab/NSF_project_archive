#!/usr/bin/env python

from nbformat import write
import rospy
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
import matplotlib.pylab as pl
import matplotlib as mpl
from mpl_toolkits.mplot3d import axes3d,Axes3D
from human_prediction.quat_functions import *
import os
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean, minkowski
from human_prediction.network import *
from std_msgs.msg import Float32MultiArray
import rospkg
from human_prediction.skeleton import *
from scipy import interpolate as interp
import time
from scipy.signal import butter, lfilter


if __name__ == '__main__':

    rospy.init_node('show_prediction', anonymous=True)
    rospack = rospkg.RosPack()
    this_pack = rospack.get_path('human_prediction')

    file_num_str = rospy.get_param("/plot/file_num")
    do_plots = int(rospy.get_param("/plot/show_plots"))
    save = bool(int(rospy.get_param("/plot/save")))
    print(file_num_str)
    print(type(file_num_str)==int)
    if not type(file_num_str)==int:
        file_num_range = np.array(file_num_str.split(',')).astype(int)
    else:
        file_num_range = np.array([file_num_str])
    print(file_num_range)
    file_nums = []
    if (file_num_range.shape[0]==1):
        if (file_num_range[0]==-1):
            rec_nums = np.array([0])
            for filename in os.listdir(os.path.join(this_pack,'data')):
                # print(filename)
                if filename.startswith('recording_'):
                    if filename.endswith('.csv'):
                        file_parts = filename.split('_')
                        rec_nums = np.append(rec_nums,file_parts[1].split('.')[0])
            file_num = np.max(rec_nums.astype(int))
        else:
            file_num = file_num_range[0]
        file_nums.append(file_num)
    else:
        all_files = os.listdir(os.path.join(this_pack,'data'))
        for i in range(file_num_range[0],file_num_range[1]+1):
            if 'recording_{}.csv'.format(i) in all_files:
                file_nums.append(i)
    print(file_nums)
    # for filename in os.listdir(os.path.join(this_pack,'data')):
    #     if filename.startswith('recording_') and filename.endswith('.csv'):
    #         file_parts = filename.split('_')
    #         file_num = int(file_parts[1].split('.')[0])
    #         if file_num<80:
    #             continue
    #     else:
    #         continue
    speeds = np.empty((0))
    final_errors = np.empty((0))
    start_delays = np.empty((0))
    peak_vels = np.empty((0))
    dists = np.empty((0))
    durations = np.empty((0))

    force_hand = rospy.get_param("/plot/force_hand")

    for file_num in file_nums:
        prediction = np.genfromtxt(os.path.join(this_pack,'data','prediction_{}.csv'.format(file_num)),dtype=float,delimiter=',')
        print('opening recording_{}'.format(file_num))
        data = np.genfromtxt(os.path.join(this_pack,'data','recording_{}.csv'.format(file_num)),dtype=float,delimiter=',')
        if data.shape[0]==0:
            continue
        if (data.shape[0]>800) and save:
            print('record {} is over 8 seconds, skipping'.format(file_num))
            continue
        if (len(data.shape)==1) or (data.shape[1]==0):
            print(data.shape)
            print('record {} is missing columns'.format(file_num))
            continue
        
        if len(force_hand) == 0:
            if data[0,1]<data[0,5]:
                wrist = False
                print('right')
            else:
                wrist = True
                print('left')
        else:
            if force_hand=='right':
                wrist = False
                print('right')
            elif force_hand=='left':
                wrist = True
                print('left')
        l_wrist_vels = np.linalg.norm(np.diff(data[:,[60,61,62]],axis=0),axis=1)
        r_wrist_vels = np.linalg.norm(np.diff(data[:,[51,52,53]],axis=0),axis=1)
        l_wrist_errors = np.linalg.norm(data[:,[60,61,62]]-data[:,[1,2,3]],axis=1)
        r_wrist_errors = np.linalg.norm(data[:,[51,52,53]]-data[:,[1,2,3]],axis=1)
   
        l_wrist_error_avg = np.zeros_like(l_wrist_errors)
        r_wrist_error_avg = np.zeros_like(r_wrist_errors)
        l_wrist_error_vels_avg = np.zeros_like(l_wrist_error_avg)
        r_wrist_error_vels_avg = np.zeros_like(r_wrist_error_avg)
        d_starts =np.empty((0))
        filt = butter(1, 0.001, btype='lowpass', analog=False)
        # d_starts.append(0)
        d_stops = np.empty((0))
        in_div = False
        v1s =np.zeros_like(r_wrist_error_avg)
        v2s =np.zeros_like(r_wrist_error_avg)
        m = 20
        d_start = 0
        accs = np.zeros_like(r_wrist_error_avg)
        num_sgn_flips = 0
        first_sgn_flip = 0
        max_deviation = 0
        min_out_dev = 10
        tmp_start = 0
        initial_error=0
        for i in range(l_wrist_errors.shape[0]):
            l_wrist_error_avg[i] = np.mean(l_wrist_errors[max(i-20,0):i+1])
            r_wrist_error_avg[i] = np.mean(r_wrist_errors[max(i-20,0):i+1])
            if i==0:
                if wrist:
                    initial_error = l_wrist_error_avg[i]
                else:
                    initial_error = r_wrist_error_avg[i]
                if initial_error<0.2:
                    print('init error <0.2',file_num)
            # print('i:{},in_div:{}'.format(i,in_div))
            # print('m1:{}'.format(r_wrist_error_avg[i]))
            if i>0:
                l_wrist_error_vels_avg[i] = np.mean(np.diff(l_wrist_error_avg[max(i-50,0):i+1]))
                r_wrist_error_vels_avg[i] = np.mean(np.diff(r_wrist_error_avg[max(i-50,0):i+1]))
                if wrist:
                    accs[i] = np.mean(np.diff(l_wrist_error_vels_avg[max(i-20,0):i+1]))
                else:
                    accs[i] = np.mean(np.diff(r_wrist_error_vels_avg[max(i-20,0):i+1]))
            else: 
                l_wrist_error_vels_avg[i] = 0
                r_wrist_error_vels_avg[i] = 0
                accs[i] = 0
            # print('m2:{}'.format(r_wrist_error_vels_avg[i]))
            if wrist:
                d = l_wrist_error_vels_avg[:i+1]
                w_error = l_wrist_error_avg[i]
            else:
                d = r_wrist_error_vels_avg[:i+1]
                w_error = r_wrist_error_avg[i]
            v1 = np.mean(d[-m:])

            v1s[i] = v1
            # v1s.append(lfilter(filt[0],filt[1],d[-20:])[-1])
            v2 = np.mean(d[-2*m:-m])
            v2s[i] = v2
            v3 = np.mean(d[-m:])
            v4 = np.mean(d[-2*m:-m])
            # print('v1:{}'.format(v1))
            # print('v2:{}'.format(v2))
            # print('v3:{}'.format(v3))
            # print('v4:{}'.format(v4))
            sgn_flip = (i>m+5) and (v1s[i]<v2s[i]) and (v1s[max(i-1,0)]>v2s[max(i-1,0)]) #!= np.sign([v1s[max(i-1,0)]-v2s[max(i-1,0)]]))
            max_deviation = max(np.max(np.abs([v1,v2,v3,v4])),max_deviation)
            # print('i:{}{},{},sgn_flip:{},{},{}'.format(i,in_div,max_deviation,sgn_flip, np.sign([v1s[i]-v2s[i]]),np.sign([v1s[max(i-1,0)]-v2s[max(i-1,0)]])))
            
            if d_stops.shape[0]>0:
                last_stop = d_stops[-1]
            else:
                last_stop = 0
            if d_starts.shape[0]>0:
                last_start = d_starts[-1]
            else:
                last_start = 0
            # print('{},{:.5},{:.5},{:.5},{:.5},{},{}'.format(i,v1,v2,v3,v4,last_stop,last_stop-d_start))
            if ((((v1<0) and (v2>0)) or ((v1>0) and (v2<0))) or sgn_flip):
                if in_div and sgn_flip:
                    num_sgn_flips+=1
                if (not in_div) and sgn_flip:
                    first_sgn_flip = i
                if (not in_div) and ((i-last_stop)>min_out_dev) and (last_stop-d_start<100):
                    max_deviation = 0
                    tmp_start = i
                    in_div = True
                if (in_div) and ((max_deviation<0.0002) or (w_error>initial_error-0.02)) and (w_error>0.2):
                    # if d_stops.shape[0]>0:
                    #     if (i-d_stops[-1])>min_out_dev:
                    #         d_starts =np.append(d_starts,i)
                    #         print('start1:{}'.format(i))
                    # else:
                    d_starts =np.append(d_starts,i)
                    # print('start2:{}'.format(i))

            if in_div:
                if (i-last_start>50) and (((v3>0) and (v4<0)) or ((v3<0) and (v4>0))) and (max_deviation>0.001):
                    in_div = False
                    d_stops = np.append(d_stops,i)
                    if d_starts.shape[0]>0:
                        d_start = d_starts[-1]- min(i,m)
                    else:
                        d_start = 0
                    # print('stop:{}'.format(i))
        # v1s = lfilter(filt[0],filt[1],l_wrist_error_vels_avg)
        if in_div and (max_deviation>0.001):
                d_stops = np.append(d_stops,l_wrist_errors.shape[0]-1)
                if d_starts.shape[0]>0:
                    d_start = d_starts[-1] - min(i,m)
                else:
                    d_start = 0
        if len(d_stops)==0:
            d_stops = np.append(d_stops,l_wrist_errors.shape[0]-1)
        if d_stops[-1] < l_wrist_errors.shape[0]-1:
            d_stop = d_stops[-1] - min(i,m)
        else:
            d_stop = d_stops[-1]
        print('d_starts:{},d_stops:{}, {}, {}'.format(d_start,d_stop,num_sgn_flips,first_sgn_flip))
        if (do_plots>0):
            if (do_plots>1):
                fig = plt.figure()
                ax = fig.add_subplot(projection='3d')
                print('{},{}'.format(data.shape[0],prediction.shape[0]))
                colors = pl.cm.winter(np.linspace(0,1,prediction.shape[0]))
                colors2 = pl.cm.jet(np.linspace(0,1,data.shape[0]))
                reaching_tgt = data[0,1:4]
                ax.scatter(reaching_tgt[0],reaching_tgt[1],reaching_tgt[2],color='tab:red')
                for i in range(prediction.shape[0]):
                    c_ = colors[i]
                    ax.plot([prediction[i,32],prediction[i,35]],[prediction[i,33],prediction[i,36]],[prediction[i,34],prediction[i,37]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,38],prediction[i,35]],[prediction[i,39],prediction[i,36]],[prediction[i,40],prediction[i,37]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,41],prediction[i,35]],[prediction[i,42],prediction[i,36]],[prediction[i,43],prediction[i,37]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,41],prediction[i,44]],[prediction[i,42],prediction[i,45]],[prediction[i,43],prediction[i,46]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,47],prediction[i,44]],[prediction[i,48],prediction[i,45]],[prediction[i,49],prediction[i,46]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,50],prediction[i,35]],[prediction[i,51],prediction[i,36]],[prediction[i,52],prediction[i,37]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,50],prediction[i,53]],[prediction[i,51],prediction[i,54]],[prediction[i,52],prediction[i,55]],c=c_,linestyle='dashed')
                    ax.plot([prediction[i,56],prediction[i,53]],[prediction[i,57],prediction[i,54]],[prediction[i,58],prediction[i,55]],c=c_,linestyle='dashed')
                for i in range(data.shape[0]):
                    c_ = colors2[i]
                    act_data = data
                    ax.plot([act_data[i,36],act_data[i,39]],[act_data[i,37],act_data[i,40]],[act_data[i,38],act_data[i,41]],c=c_)
                    ax.plot([act_data[i,42],act_data[i,39]],[act_data[i,43],act_data[i,40]],[act_data[i,44],act_data[i,41]],c=c_)
                    ax.plot([act_data[i,45],act_data[i,39]],[act_data[i,46],act_data[i,40]],[act_data[i,47],act_data[i,41]],c=c_)
                    ax.plot([act_data[i,45],act_data[i,48]],[act_data[i,46],act_data[i,49]],[act_data[i,47],act_data[i,50]],c=c_)
                    ax.plot([act_data[i,51],act_data[i,48]],[act_data[i,52],act_data[i,49]],[act_data[i,53],act_data[i,50]],c=c_)
                    ax.plot([act_data[i,54],act_data[i,39]],[act_data[i,55],act_data[i,40]],[act_data[i,56],act_data[i,41]],c=c_)
                    ax.plot([act_data[i,54],act_data[i,57]],[act_data[i,55],act_data[i,58]],[act_data[i,56],act_data[i,59]],c=c_)
                    ax.plot([act_data[i,60],act_data[i,57]],[act_data[i,61],act_data[i,58]],[act_data[i,62],act_data[i,59]],c=c_)


                fig2 = plt.figure()
                ax2 = fig2.add_subplot(projection='3d')
                reaching_tgt = data[0,1:4]
                ax2.scatter(reaching_tgt[0],reaching_tgt[1],reaching_tgt[2],color='tab:red')
                i=0
                c_ = colors[i]
                ax2.plot([prediction[i,32],prediction[i,35]],[prediction[i,33],prediction[i,36]],[prediction[i,34],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,38],prediction[i,35]],[prediction[i,39],prediction[i,36]],[prediction[i,40],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,41],prediction[i,35]],[prediction[i,42],prediction[i,36]],[prediction[i,43],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,41],prediction[i,44]],[prediction[i,42],prediction[i,45]],[prediction[i,43],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,47],prediction[i,44]],[prediction[i,48],prediction[i,45]],[prediction[i,49],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,50],prediction[i,35]],[prediction[i,51],prediction[i,36]],[prediction[i,52],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,50],prediction[i,53]],[prediction[i,51],prediction[i,54]],[prediction[i,52],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,56],prediction[i,53]],[prediction[i,57],prediction[i,54]],[prediction[i,58],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                c_ = colors2[i]
                ax2.plot([data[i,36],data[i,39]],[data[i,37],data[i,40]],[data[i,38],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,42],data[i,39]],[data[i,43],data[i,40]],[data[i,44],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,45],data[i,39]],[data[i,46],data[i,40]],[data[i,47],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,45],data[i,48]],[data[i,46],data[i,49]],[data[i,47],data[i,50]],c=c_, linewidth=1.5)
                ax2.plot([data[i,51],data[i,48]],[data[i,52],data[i,49]],[data[i,53],data[i,50]],c=c_, linewidth=1.5)
                ax2.plot([data[i,54],data[i,39]],[data[i,55],data[i,40]],[data[i,56],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,54],data[i,57]],[data[i,55],data[i,58]],[data[i,56],data[i,59]],c=c_, linewidth=1.5)
                ax2.plot([data[i,60],data[i,57]],[data[i,61],data[i,58]],[data[i,62],data[i,59]],c=c_, linewidth=1.5)
                i=-1
                c_ = colors[prediction.shape[0]-1]
                ax2.plot([prediction[i,32],prediction[i,35]],[prediction[i,33],prediction[i,36]],[prediction[i,34],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,38],prediction[i,35]],[prediction[i,39],prediction[i,36]],[prediction[i,40],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,41],prediction[i,35]],[prediction[i,42],prediction[i,36]],[prediction[i,43],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,41],prediction[i,44]],[prediction[i,42],prediction[i,45]],[prediction[i,43],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,47],prediction[i,44]],[prediction[i,48],prediction[i,45]],[prediction[i,49],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,50],prediction[i,35]],[prediction[i,51],prediction[i,36]],[prediction[i,52],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,50],prediction[i,53]],[prediction[i,51],prediction[i,54]],[prediction[i,52],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                ax2.plot([prediction[i,56],prediction[i,53]],[prediction[i,57],prediction[i,54]],[prediction[i,58],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                c_ = colors2[data.shape[0]-1]
                ax2.plot([data[i,36],data[i,39]],[data[i,37],data[i,40]],[data[i,38],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,42],data[i,39]],[data[i,43],data[i,40]],[data[i,44],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,45],data[i,39]],[data[i,46],data[i,40]],[data[i,47],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,45],data[i,48]],[data[i,46],data[i,49]],[data[i,47],data[i,50]],c=c_, linewidth=1.5)
                ax2.plot([data[i,51],data[i,48]],[data[i,52],data[i,49]],[data[i,53],data[i,50]],c=c_, linewidth=1.5)
                ax2.plot([data[i,54],data[i,39]],[data[i,55],data[i,40]],[data[i,56],data[i,41]],c=c_, linewidth=1.5)
                ax2.plot([data[i,54],data[i,57]],[data[i,55],data[i,58]],[data[i,56],data[i,59]],c=c_, linewidth=1.5)
                ax2.plot([data[i,60],data[i,57]],[data[i,61],data[i,58]],[data[i,62],data[i,59]],c=c_, linewidth=1.5)
                for i in range(prediction.shape[0]-1):
                    c_ = colors[i]
                    for j in range(9):
                        ax2.plot([prediction[i,j*3+32],prediction[i+1,j*3+32]],[prediction[i,j*3+33],prediction[i+1,j*3+33]],[prediction[i,j*3+34],prediction[i+1,j*3+34]],c=c_,ls=(0, (1, 10)))

                for i in range(data.shape[0]-1):
                    c_ = colors2[i]
                    for j in range(9):
                        ax2.plot([data[i,j*3+36],data[i+1,j*3+36]],[data[i,j*3+37],data[i+1,j*3+37]],[data[i,j*3+38],data[i+1,j*3+38]],c=c_,ls=(0, (5, 10)))


                fig3 = plt.figure()
                ax3 = fig3.add_subplot(projection='3d')
                reaching_tgt = data[0,1:4]
                ax3.scatter(reaching_tgt[0],reaching_tgt[1],reaching_tgt[2],color='tab:red')
                i=0
                c_ = colors[i]
                ax3.plot([prediction[i,32],prediction[i,35]],[prediction[i,33],prediction[i,36]],[prediction[i,34],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,38],prediction[i,35]],[prediction[i,39],prediction[i,36]],[prediction[i,40],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,41],prediction[i,35]],[prediction[i,42],prediction[i,36]],[prediction[i,43],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,41],prediction[i,44]],[prediction[i,42],prediction[i,45]],[prediction[i,43],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,47],prediction[i,44]],[prediction[i,48],prediction[i,45]],[prediction[i,49],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,50],prediction[i,35]],[prediction[i,51],prediction[i,36]],[prediction[i,52],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,50],prediction[i,53]],[prediction[i,51],prediction[i,54]],[prediction[i,52],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,56],prediction[i,53]],[prediction[i,57],prediction[i,54]],[prediction[i,58],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)

                i=-1
                c_ = colors[prediction.shape[0]-1]
                ax3.plot([prediction[i,32],prediction[i,35]],[prediction[i,33],prediction[i,36]],[prediction[i,34],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,38],prediction[i,35]],[prediction[i,39],prediction[i,36]],[prediction[i,40],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,41],prediction[i,35]],[prediction[i,42],prediction[i,36]],[prediction[i,43],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,41],prediction[i,44]],[prediction[i,42],prediction[i,45]],[prediction[i,43],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,47],prediction[i,44]],[prediction[i,48],prediction[i,45]],[prediction[i,49],prediction[i,46]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,50],prediction[i,35]],[prediction[i,51],prediction[i,36]],[prediction[i,52],prediction[i,37]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,50],prediction[i,53]],[prediction[i,51],prediction[i,54]],[prediction[i,52],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                ax3.plot([prediction[i,56],prediction[i,53]],[prediction[i,57],prediction[i,54]],[prediction[i,58],prediction[i,55]],c=c_,linestyle='dashed', linewidth=1.5)
                for i in range(prediction.shape[0]-1):
                    c_ = colors[i]
                    for j in range(9):
                        ax3.plot([prediction[i,j*3+32],prediction[i+1,j*3+32]],[prediction[i,j*3+33],prediction[i+1,j*3+33]],[prediction[i,j*3+34],prediction[i+1,j*3+34]],c=c_,ls=(0, (1, 10)))

                fig4 = plt.figure()
                ax4 = fig4.add_subplot(projection='3d')
                reaching_tgt = data[0,1:4]
                ax4.scatter(reaching_tgt[0],reaching_tgt[1],reaching_tgt[2],color='tab:red')
                i=0
                c_ = colors2[i]
                ax4.plot([data[i,36],data[i,39]],[data[i,37],data[i,40]],[data[i,38],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,42],data[i,39]],[data[i,43],data[i,40]],[data[i,44],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,45],data[i,39]],[data[i,46],data[i,40]],[data[i,47],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,45],data[i,48]],[data[i,46],data[i,49]],[data[i,47],data[i,50]],c=c_, linewidth=1.5)
                ax4.plot([data[i,51],data[i,48]],[data[i,52],data[i,49]],[data[i,53],data[i,50]],c=c_, linewidth=1.5)
                ax4.plot([data[i,54],data[i,39]],[data[i,55],data[i,40]],[data[i,56],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,54],data[i,57]],[data[i,55],data[i,58]],[data[i,56],data[i,59]],c=c_, linewidth=1.5)
                ax4.plot([data[i,60],data[i,57]],[data[i,61],data[i,58]],[data[i,62],data[i,59]],c=c_, linewidth=1.5)
                i=-1
                c_ = colors2[data.shape[0]-1]
                ax4.plot([data[i,36],data[i,39]],[data[i,37],data[i,40]],[data[i,38],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,42],data[i,39]],[data[i,43],data[i,40]],[data[i,44],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,45],data[i,39]],[data[i,46],data[i,40]],[data[i,47],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,45],data[i,48]],[data[i,46],data[i,49]],[data[i,47],data[i,50]],c=c_, linewidth=1.5)
                ax4.plot([data[i,51],data[i,48]],[data[i,52],data[i,49]],[data[i,53],data[i,50]],c=c_, linewidth=1.5)
                ax4.plot([data[i,54],data[i,39]],[data[i,55],data[i,40]],[data[i,56],data[i,41]],c=c_, linewidth=1.5)
                ax4.plot([data[i,54],data[i,57]],[data[i,55],data[i,58]],[data[i,56],data[i,59]],c=c_, linewidth=1.5)
                ax4.plot([data[i,60],data[i,57]],[data[i,61],data[i,58]],[data[i,62],data[i,59]],c=c_, linewidth=1.5)

                for i in range(data.shape[0]-1):
                    c_ = colors2[i]
                    for j in range(9):
                        ax4.plot([data[i,j*3+36],data[i+1,j*3+36]],[data[i,j*3+37],data[i+1,j*3+37]],[data[i,j*3+38],data[i+1,j*3+38]],c=c_,ls=(0, (5, 10)))

            fig5,ax5 = plt.subplots(4,2,sharex = True, sharey=False)
            ax5 = ax5.flatten()
            if 0:
                x = np.arange(data.shape[0])*0.01
                pred_x = np.arange(prediction.shape[0])*0.1
            else:
                x = np.arange(data.shape[0])
                pred_x = np.linspace(d_start,d_stop,prediction.shape[0])
            labels = ['spine','neck', 'shoulders','r upper', 'r forearm', 'l upper arm', 'l forearm']
            colors = ['tab:blue','tab:green','tab:purple','tab:red']
            for i in range(3):
                ax5[0].plot(x,data[:,5+i],color=colors[i+1])
                ax5[0].axvline(d_start)
                ax5[0].axvline(d_stop)
                ax5[0].plot(pred_x,prediction[:,1+i],linestyle='dashed',color=colors[i+1])
            for i in range(7):
                for j in range(4):
                    ax5[i+1].set_title(labels[i])
                    ax5[i+1].plot(x,data[:,8+j+i*4],color=colors[j])
                    ax5[i+1].axvline(d_start)
                    ax5[i+1].axvline(d_stop)
                    ax5[i+1].plot(pred_x,prediction[:,4+j+i*4],linestyle='dashed',color=colors[j])
    
        acc_var = np.var(accs[np.abs(accs - np.mean(accs))<2*np.std(accs)])
        if wrist:
            final_error = l_wrist_error_avg[int(d_stop)]
        else:
            final_error = r_wrist_error_avg[int(d_stop)]
        if (do_plots>0):
            fig8,ax8 = plt.subplots(1,1,sharex = True, sharey=False)
            if wrist:
                ax8.plot(l_wrist_errors)
                ax8.plot(l_wrist_error_avg)
            else:
                print('plotting right errors')
                ax8.plot(r_wrist_errors)
                ax8.plot(r_wrist_error_avg)
            ax8.axvline(d_start)
            ax8.axvline(d_stop)
            ax8.set_title('error')

            fig6,ax6 = plt.subplots(1,1,sharex = True, sharey=False)
            if wrist:
                ax6.plot(l_wrist_error_vels_avg)
            else:
                ax6.plot(r_wrist_error_vels_avg)
            ax6.axvline(d_start)
            ax6.axvline(d_stop)
            ax6.set_title('vel')

            fig9,ax9 = plt.subplots(1,1,sharex = True, sharey=False)
            ax9.plot(accs)
            ax9.set_title('accs')
            print('{}, acc var:{}'.format('accept' if (acc_var<1E-9) and (final_error<0.2) else 'reject',acc_var))

            fig7,ax7 = plt.subplots(1,1,sharex = True, sharey=False)
            ax7.plot(v1s)
            ax7.plot(v2s)
            ax7.axvline(d_start)
            ax7.axvline(d_stop)
            ax7.set_title('v1 v2')

        if (final_error<0.2) and (acc_var<3E-8):
            duration = (d_stop-d_start)*0.011
            durations = np.append(durations,duration)
            start_delays = np.append(start_delays,d_start*0.011)
            if wrist:
                dist = np.linalg.norm(data[int(d_stop),[60,61,62]]-data[int(d_start),[60,61,62]])
                dists = np.append(dists,dist)
                final_errors = np.append(final_errors,np.min(l_wrist_errors[int(d_start):int(d_stop)]))
                peak_vels = np.append(peak_vels,np.max(np.abs(l_wrist_error_vels_avg)))
            else:
                dist = np.linalg.norm(data[int(d_stop),[60,61,62]]-data[int(d_start),[51,52,63]])
                dists = np.append(dists,dist)
                final_errors = np.append(final_errors,np.min(r_wrist_errors[int(d_start):int(d_stop)]))
                peak_vels = np.append(peak_vels,np.max(np.abs(r_wrist_error_vels_avg)))
            speeds = np.append(speeds,dist/duration)
            print('rec {}, duration:{:.3}, dist:{:.3}, speed:{:.3}'.format(file_num,duration,dist,dist/duration))
            record_cols = np.concatenate((np.arange(1,4),np.arange(5,36))).astype(int)
            record_rows = np.arange(d_start,d_stop+1).astype(int)
            if save:
                print('rec {} saved'.format(file_num))
                np.savetxt(os.path.join(this_pack,'data','training_data_fixed_{}_iter_{}_{}.csv'.format(file_num,file_num,'_w2_' if wrist else '_w1_')),data[:,record_cols][record_rows,:],delimiter=',')
            else:
                print('rec {} not saved'.format(file_num))

        # print('prediction end')
        # print(prediction[-1,32:59].reshape((9,3)))
        # print('actual end')
        # print(data[-1,36:63].reshape((9,3)))
        if (do_plots>0):
            plt.show()
    if len(file_nums)>1:
        print('avg final error:{}'.format(np.mean(final_errors)))
        print('avg speed:{}'.format(np.mean(speeds)))
        print('avg start delay:{}'.format(np.mean(start_delays)))
        fig = plt.figure()
        speeds_no_outlier_ids = np.where(np.abs(speeds-np.mean(speeds))<2*np.std(speeds))[0]
        plt.hist(speeds[speeds_no_outlier_ids], bins=50)
        plt.xlabel('reach peak velocity (meters/second)')
        plt.ylabel('bin count')
        fig14 = plt.figure()
        plt.scatter(dists[speeds_no_outlier_ids],speeds[speeds_no_outlier_ids])
        plt.xlabel('distance between wrist start and end (meters)')
        plt.ylabel('reach average velocity (meters/second)')
        fig10 = plt.figure()
        plt.hist(start_delays[np.abs(start_delays-np.mean(start_delays))<2*np.std(start_delays)], bins=50)
        plt.xlabel('reach start delay (seconds)')
        plt.ylabel('bin count')
        fig11 = plt.figure()
        final_errors_no_outliers = np.copy(final_errors[np.abs(final_errors-np.mean(final_errors))<2*np.std(final_errors)])
        print('reach position error {}'.format(np.mean(final_errors_no_outliers)))
        plt.hist(final_errors_no_outliers, bins=50)
        plt.xlabel('reach position error (meters)')
        plt.ylabel('bin count')
        fig12 = plt.figure()
        peak_vels_no_outlier_ids = np.where(np.abs(peak_vels-np.mean(peak_vels))<2*np.std(peak_vels))[0]
        plt.scatter(dists[peak_vels_no_outlier_ids],peak_vels[peak_vels_no_outlier_ids])
        plt.xlabel('distance between wrist start and end (meters)')
        plt.ylabel('motion peak velocity (meters/seconds)')
        fig13 = plt.figure()
        durations_no_outlier_ids = np.where(np.abs(durations-np.mean(durations))<2*np.std(durations))[0]
        plt.scatter(dists[durations_no_outlier_ids],durations[durations_no_outlier_ids])
        plt.xlabel('distance between wrist start and end (meters)')
        plt.ylabel('motion duration (seconds)')
        plt.show()
