#include <ros/ros.h>

#include <std_msgs/Float32.h>
#include <std_msgs/Float32MultiArray.h>
#include <sensor_msgs/JointState.h>

#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/robot_model_loader/robot_model_loader.h>

#include <fcl/narrowphase/detail/gjk_solver_indep.h>
#include <fcl/narrowphase/detail/gjk_solver_libccd.h>
#include <fcl/geometry/geometric_shape_to_BVH_model.h>
#include <fcl/narrowphase/distance.h>
#include <fcl/narrowphase/collision.h>
#include <fcl/math/bv/utility.h>
#include <fcl/geometry/collision_geometry-inl.h>
#include <fcl/geometry/bvh/detail/BV_fitter.h>
#include <fcl/geometry/octree/octree.h>

#include <Eigen/Dense>

#include <xmlrpcpp/XmlRpcValue.h>

#include <mutex>
#include <string>
#include <exception>

class distance_reporter {
    public:
    distance_reporter(ros::NodeHandle nh, robot_state::RobotStatePtr state, moveit::core::RobotModelConstPtr robot_model);
    private:
    robot_state::RobotStatePtr state_;
    std::vector<double> human_link_lengths;
    std::vector<double> human_link_radii;
    std::vector<double> joint_positions;
    std::vector<Eigen::Quaternionf> live_human_quats;
    std::vector<Eigen::Vector3f> live_human_points;
    std::vector<std::string> joint_names;
    std::mutex mtx;
    std::mutex mtx2;
    ros::Timer collision_timer;
    ros::Publisher pub_dist;
    ros::Publisher pub_all_dist;
    ros::Subscriber sub_skel_pts;
    ros::Subscriber sub_skel_quats;
    ros::Subscriber joint_states_sub;
    std::vector<Eigen::Vector3f> link_bb_offsets;
    std::vector<fcl::Boxf> link_boxes;
    std::vector<const robot_state::LinkModel*> robot_links;
    bool joint_state_ready;
    void collision_check_thread(const ros::TimerEvent& event);
    void skel_quats_cb(const std_msgs::Float32MultiArray::ConstPtr& msg);
    void skel_pts_cb(const std_msgs::Float32MultiArray::ConstPtr& msg);
    void jnt_state_callback(const sensor_msgs::JointState::ConstPtr& msg);
    int n_dof_;
    protected:
    ros::NodeHandle nh_;
};
