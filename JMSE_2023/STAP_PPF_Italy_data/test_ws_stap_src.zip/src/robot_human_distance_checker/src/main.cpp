#include <robot_human_distance_checker/distance_reporter.h>

int main(int argc, char** argv) {

    ros::init(argc,argv,"distance_reporter");
    ros::NodeHandle nh;
    ros::AsyncSpinner spinner(1);
    spinner.start();

    std::string plan_group = "manipulator";
    if (!nh.getParam("/plan_group",plan_group))
    {
        if (!nh.getParam("/rh_dist_checker/plan_group",plan_group))
        {
            ROS_WARN("plan_group is not defined");
        }
    }

    moveit::planning_interface::MoveGroupInterface move_group(plan_group);
    // actionlib::SimpleActionClient<moveit_msgs::MoveGroupAction> mg_action_client = move_group.getMoveGroupClient();
    const robot_state::JointModelGroup* joint_model_group_ = move_group.getCurrentState()->getJointModelGroup(plan_group);
    robot_model_loader::RobotModelLoaderPtr robot_model_loader = robot_model_loader::RobotModelLoaderPtr(new robot_model_loader::RobotModelLoader("robot_description"));
    const robot_model::RobotModelPtr& model = robot_model_loader->getModel();

    distance_reporter dist(nh,move_group.getCurrentState(),model);

    ros::waitForShutdown();

    return 0;
}