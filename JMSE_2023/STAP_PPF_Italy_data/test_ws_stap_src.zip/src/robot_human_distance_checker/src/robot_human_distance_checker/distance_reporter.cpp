#include <robot_human_distance_checker/distance_reporter.h>

distance_reporter::distance_reporter(ros::NodeHandle nh, robot_state::RobotStatePtr state, moveit::core::RobotModelConstPtr robot_model):nh_(nh),state_(state) {

    joint_states_sub = nh_.subscribe<sensor_msgs::JointState>("/joint_states",1,&distance_reporter::jnt_state_callback,this);

    sub_skel_pts = nh_.subscribe<std_msgs::Float32MultiArray>("/skeleton_points",1,&distance_reporter::skel_pts_cb,this);
    sub_skel_quats = nh_.subscribe<std_msgs::Float32MultiArray>("/skeleton_quats",1,&distance_reporter::skel_quats_cb,this);
    pub_dist = nh_.advertise<std_msgs::Float32>("/min_robot_human_dist", 0,false);
    pub_all_dist = nh_.advertise<std_msgs::Float32MultiArray>("/all_robot_human_dist", 0,false);

    if (!nh_.getParam("/human_link_lengths", human_link_lengths)) {
        ROS_ERROR("couldn't read human dimensions");
        throw std::invalid_argument("/human_link_lengths is not defined");
    }
    if (!nh_.getParam("/human_link_radii", human_link_radii)) {
        ROS_ERROR("couldn't read human radii");
        throw std::invalid_argument("/human_link_radii is not defined");
    } 
    human_link_lengths.erase(human_link_lengths.begin()+2);
    human_link_radii.erase(human_link_radii.begin()+2);

    XmlRpc::XmlRpcValue dist_links_xml;
    std::vector<std::string> dist_links;
    if (!nh_.getParam("/rh_dist_checker/distance_links", dist_links_xml))
    {
      ROS_ERROR("/rh_dist_checker/distance_links is not defined in distance_robot.yaml");
      throw std::invalid_argument("/rh_dist_checker/distance_links is not defined in distance_robot.yaml");
    }

    for (int i=0; i<dist_links_xml.size();i++) {
        dist_links.push_back(dist_links_xml[i]);
        ROS_INFO_STREAM("link from distance_links:"<<dist_links.back());
    }

    std::vector<const robot_state::LinkModel*> links = robot_model->getLinkModels();
    for (int i=0;i<int(links.size());i++) {
        std::string link_name = links[i]->getName();
        if (std::find(dist_links.begin(),dist_links.end(),link_name)!=dist_links.end()) {
            ROS_INFO_STREAM("link name "<<link_name);
            // if (link_name.substr(link_name.length()-4) == "link") {
            std::vector<shapes::ShapeConstPtr> link_shape = links[i]->getShapes();
            if (link_shape.size()>0){
                const Eigen::Vector3f& extents_tmp = links[i]->getShapeExtentsAtOrigin().cast<float>();
                Eigen::Vector3f extents = extents_tmp;
                const Eigen::Vector3f& offset_tmp = links[i]->getCenteredBoundingBoxOffset().cast<float>();
                Eigen::Vector3f offset = offset_tmp;

                ROS_INFO_STREAM("link name "<<link_name<<", extents:"<<extents.transpose()<<", offset:"<<offset.transpose());
                link_bb_offsets.push_back(offset);
                // Eigen::Isometry3d transform;
                // transform.setIdentity();
                // transform.translate(offset);
                // moveit::core::AABB aabb;
                // aabb.extendWithTransformedBox(transform,extents);
                // link_raw_pts.push_back(boxPts(extents));
                link_boxes.push_back(fcl::Boxf(extents[0],extents[1],extents[2]));
                robot_links.push_back(links[i]);
            }
        }
    }

    collision_timer = nh_.createTimer(ros::Duration(1.0/30.0), &distance_reporter::collision_check_thread, this);
}

void distance_reporter::skel_pts_cb(const std_msgs::Float32MultiArray::ConstPtr& msg) {
    std::vector<float> camera_keypoints = msg->data;
    std::lock_guard<std::mutex> lck(mtx);
    live_human_points.clear();
    for (int i=0;i<int(double(camera_keypoints.size())/3.0);i++) {
        live_human_points.push_back(Eigen::Vector3f(camera_keypoints[i*3],camera_keypoints[i*3+1],camera_keypoints[i*3+2]));
    }
}

void distance_reporter::skel_quats_cb(const std_msgs::Float32MultiArray::ConstPtr& msg) {
    std::lock_guard<std::mutex> lck(mtx2);
    std::vector<float> pose_elements = msg->data;
    live_human_quats.clear();
    for (int i=0;i<7;i++){
        live_human_quats.push_back(Eigen::Quaternionf(pose_elements[i*4+4],pose_elements[i*4+5],pose_elements[i*4+6],pose_elements[i*4+7]));
    }
}

  
void distance_reporter::collision_check_thread(const ros::TimerEvent& event) {
    std::vector<float> min_human_dists;
    std_msgs::Float32 min_dist_msg;
    std_msgs::Float32MultiArray all_min_dist_msg;
    std::vector<Eigen::Vector3f> human_points;
    std::vector<Eigen::Quaternionf> quats;
    float min_dist = std::numeric_limits<float>::infinity();
    std::vector<Eigen::Vector3f> obj_centroids;
    fcl::DistanceRequest<float> req(true);
    fcl::DistanceResult<float> res;
    if (!joint_state_ready) goto end_dists;
    mtx.lock();
    human_points = live_human_points;
    mtx.unlock();
    mtx2.lock();
    quats = live_human_quats;
    mtx2.unlock();
    if (int(human_points.size())<9) goto end_dists;
    if (int(quats.size())<human_link_lengths.size()+1) goto end_dists;
    if (joint_positions.empty()) goto end_dists;
    obj_centroids.push_back(Eigen::Vector3f(0.5*(human_points[1][0]+human_points[0][0]),0.5*(human_points[1][1]+human_points[0][1]),0.5*(human_points[1][2]+human_points[0][2])));
    obj_centroids.push_back(Eigen::Vector3f(0.5*(human_points[2][0]+human_points[1][0]),0.5*(human_points[2][1]+human_points[1][1]),0.5*(human_points[2][2]+human_points[1][2])));
    obj_centroids.push_back(Eigen::Vector3f(0.5*(human_points[4][0]+human_points[3][0]),0.5*(human_points[4][1]+human_points[3][1]),0.5*(human_points[4][2]+human_points[3][2])));
    obj_centroids.push_back(Eigen::Vector3f(0.5*(human_points[4][0]+human_points[5][0]),0.5*(human_points[4][1]+human_points[5][1]),0.5*(human_points[4][2]+human_points[5][2])));
    obj_centroids.push_back(Eigen::Vector3f(0.5*(human_points[7][0]+human_points[6][0]),0.5*(human_points[7][1]+human_points[6][1]),0.5*(human_points[7][2]+human_points[6][2])));
    obj_centroids.push_back(Eigen::Vector3f(0.5*(human_points[8][0]+human_points[7][0]),0.5*(human_points[8][1]+human_points[7][1]),0.5*(human_points[8][2]+human_points[7][2])));
    
    quats.erase(quats.begin()+2);
    state_->setVariablePositions(joint_positions);
    min_human_dists.resize(int(human_link_lengths.size()));
    for (int i=0;i<human_link_lengths.size();i++) min_human_dists[i] = 1000;
    for (int i=0;i<robot_links.size();i++) {
        Eigen::Isometry3f offset_transform;
        offset_transform.setIdentity();
        offset_transform.translate(link_bb_offsets[i]);
        fcl::Transform3f link_transform = fcl::Transform3f(state_->getGlobalLinkTransform(robot_links[i]).cast<float>()*offset_transform);
        for (int j=0;j<human_link_lengths.size();j++) {
            // std::cout<<"quat "<<j<<":<"<<quats[j].w()<<","<<quats[j].x()<<","<<quats[j].y()<<","<<quats[j].z()<<">"<<std::endl;
            if ((quats[j].squaredNorm()>0.9)&&(quats[j].squaredNorm()<1.1)) {
                fcl::Transform3f obj_pose = fcl::Transform3f::Identity();
                obj_pose.linear() = quats[j].toRotationMatrix();
                obj_pose.translation() = obj_centroids[j];
                fcl::Cylinderf s((float)human_link_radii[j],(float)human_link_lengths[j]);
                fcl::distance(&link_boxes[i],link_transform,&s,obj_pose,req,res);
                min_dist = std::min(min_dist, std::max(res.min_distance,float(0.0)));
                min_human_dists[j] = std::min(min_human_dists[j],std::max(res.min_distance,float(0.0)));
            } else {
                ROS_ERROR_STREAM("error with quat:"<<j<<":<"<<quats[j].w()<<","<<quats[j].x()<<","<<quats[j].y()<<","<<quats[j].z()<<">");
            }
        }
    }
    min_dist_msg.data = min_dist;
    pub_dist.publish(min_dist_msg);
    for (int i=0;i<min_human_dists.size();i++) all_min_dist_msg.data.push_back(min_human_dists[i]);
    end_dists: pub_all_dist.publish(all_min_dist_msg);
}


void distance_reporter::jnt_state_callback(const sensor_msgs::JointState::ConstPtr& msg) {
    if (joint_names.empty()) {
        for (int i=0;i<msg->name.size();i++) joint_names.push_back(msg->name[i]);
        n_dof_ = int(joint_names.size());
        std::cout<<n_dof_<<std::endl;
        joint_positions = std::vector<double>(n_dof_,0.0);
    }
    if (n_dof_==0) return;

    for (int i=0;i<n_dof_;i++) {
        joint_positions[i] = msg->position[i];
    }
    joint_state_ready = true;
}